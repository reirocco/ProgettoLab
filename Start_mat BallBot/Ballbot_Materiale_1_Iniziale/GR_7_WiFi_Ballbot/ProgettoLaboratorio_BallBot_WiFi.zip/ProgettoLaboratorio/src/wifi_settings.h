/*******************************************************************************
* File Name     : wifi_settings.h
* Version       : 1.00
* Device(s)     : RX63N
* Tool-Chain    : Renesas RX Standard Toolchain 1.0.0
* OS            : None
* H/W Platform  : YRDKRX63N
* Description   : Macro for wifi serial communication setting
*******************************************************************************/
/*******************************************************************************
* History : DD.MM.YYYY     Version     Description
*         : 16.01.2020     1.00        First release
*******************************************************************************/

#ifndef WIFI_SETTINGS_H_
#define WIFI_SETTINGS_H_


/******************************************************************************
Macro definitions
******************************************************************************/
/* Initial commands that the renesas sends for setting the wifi module */
#define WIFI_COMMAND1 "AT+CWMODE=3\r\n"
#define WIFI_COMMAND2 "AT+CIPMUX=1\r\n"
#define WIFI_COMMAND3 "AT+CIPSERVER=1\r\n"

#define SPLITTER ':' /* String splitter between header and command*/
#define DIM_HEADER 8	/* Dimension of the correct command's header */
#define DIM_COMMAND 3	/* Dimension of the correct command */
#define DIM_BUFFER 100 /* Dimension of the data buffer for the communication */
#define CORRECT_HEADER "+IPD,0,3" /* Sample of the correct header of a command */
#define OK_SETTING "OK\r\n\0\0\0\0" /* Ok response from wifi Module to correct command */
#define ERROR_SETTING "ERROR\r\n\0"	/* Erroro response from WiFi module */

typedef struct {
	char header[DIM_HEADER];	/* vector containing the header of the packet */
	char command[DIM_BUFFER];	/* vector containing the command of the packet */
	int n;	/* dimension of the command, for a correct command n=DIM_COMMAND */
} packet;		/* Struct for managing commands sent by wifi serial communication */


#endif /* WIFI_SETTINGS_H_ */
