/*******************************************************************************
* File Name     : ballbot_command.h
* Version       : 1.00
* Device(s)     : RX63N
* Tool-Chain    : Renesas RX Standard Toolchain 1.0.0
* OS            : None
* H/W Platform  : YRDKRX63N
* Description   : Macro for wifi serial communication setting
*******************************************************************************/
/*******************************************************************************
* History : DD.MM.YYYY     Version     Description
*         : 16.01.2020     1.00        First release
*******************************************************************************/
/*
 *  Created on: 16 gen 2020
 *      Author: danilogervasio
 */

#ifndef BALLBOT_COMMAND_H_
#define BALLBOT_COMMAND_H_

/* Received command for ballbot function START,STOP,FORWARD,BACKWARD,LEFT,RIGHT*/
#define START "bON"
#define STOP "bOF"
#define FORWARD "bAV"
#define BACKWARD "bIN"
#define LEFT "bSX"
#define RIGHT "bDX"


#endif /* BALLBOT_COMMAND_H_ */
