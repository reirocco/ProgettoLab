/*******************************************************************************
* File Name     : data_parser.c
* Version       : 1.03
* Device(s)     : RX63N
* Tool-Chain    : Renesas RX Standard Toolchain 1.0.0
* OS            : None
* H/W Platform  : YRDKRX63N
* Description   : Library for data parser of UART wifi communciation
*******************************************************************************/
/*******************************************************************************
* History : DD.MM.YYYY     Version     Description
*         : 06.12.2019     1.01		   First release
*         : 10.12.2019	   1.01		   Added macros for communication settings
*         : 13.12.2019	   1.02		   Added packet structure
*         : 15.12.2019	   1.03		   Added other macros for communication settings
*******************************************************************************/
/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "data_parser.h"
#include <stdbool.h>
#include <stdio.h>
#include <machine.h>
#include "platform.h"
#include "wifi_settings.h"
#include "ballbot_command.h"

packet myPacket; /* Object that contains the received packet, including its header and data */
packet* myPacket_pointer=&myPacket; /* Pointer to the packet object */
int errorFlag=0; /* Flag for checking error setting of wifi module */
/*******************************************************************************
* Function name: parseHeader
* Description  : Compare the header of the received packet with the CORRECT_HEADER in order to find a correct packet
* Argument     : none
* Return value : 1 if the packet is correct command packet, 0 if it is not a command packet
*******************************************************************************/
int parseHeader()
{
	if (!strcmp(myPacket_pointer->header,ERROR_SETTING)) /*If the header is equal to ERROR_SETTING string it means that an error has occured
															while setting the wifi module */
		errorFlag=1;

	if (!errorFlag)		/* if the error flag is on, lcd displays the error */
	{if (!strcmp(myPacket_pointer->header,OK_SETTING))
		lcd_display(LCD_LINE4,"WiFi SET");
	}else
	{
		lcd_display(LCD_LINE4,"WiFi ERROR");
	}

	/* if the header of the packet is not correct the function returns 0 (false) */
	if (!strcmp(myPacket_pointer->header,CORRECT_HEADER)) /* strcmp returns 0 if the two strings are equal */
		return 1;
	else
		return 0;
}

/*******************************************************************************
* Function name: clearCommand
* Description  : Clear the command array of the packet structure after its use
* Argument     : none
* Return value : none
*******************************************************************************/
void clearCommand()
{
	/* if the command vector has been loaded, it means that the received packet contained a
	 * correct command, so its dimension is of DIM_COMMAND
	 */
	int i;
	for (i=0;i<DIM_COMMAND;i++)	/* clear each bit of the command vector of the packet */

	{
		myPacket_pointer->command[i]=0;
	}
}

/*******************************************************************************
* Function name: parseCommand
* Description  : Parse the received command
* Argument     : none
* Return value : Char* pointing to the parsed command
*******************************************************************************/
char* parseCommand()
{
	if (!strcmp(myPacket_pointer->command,START))
			lcd_display(LCD_LINE8,"START");
	if (!strcmp(myPacket_pointer->command,STOP))
				lcd_display(LCD_LINE8,"STOP");
	if (!strcmp(myPacket_pointer->command,FORWARD))
				lcd_display(LCD_LINE8,"Forward");
	if (!strcmp(myPacket_pointer->command,BACKWARD))
				lcd_display(LCD_LINE8,"Backward");
	if (!strcmp(myPacket_pointer->command,LEFT))
				lcd_display(LCD_LINE8,"Left");
	if (!strcmp(myPacket_pointer->command,RIGHT))
				lcd_display(LCD_LINE8,"Right");


	return myPacket_pointer->command;
}


/*******************************************************************************
* Function name: split
* Description  : Split the received packet in header and command
* Argument     : none
* Return value : Char* pointing to the parsed command
*******************************************************************************/
char* split(char* data)
{
	int i=0;
	int j=0;
	while(data[i] != SPLITTER && i<DIM_HEADER) /* The first DIM_HEADER bits are put in the header array as soon as the splitter char (':') is found */
	{
		/* The header put in the packet structure may not respect the protocol of the correct header */
		myPacket_pointer->header[i]=data[i];
		i++;
	}
	myPacket_pointer->n=data[i-1];	/* the dimension of the command is the last char of the header */
	i++;

	/* In this phase it is not knowed if the received packet is a command or not, it is knowed by checking the header */
	if (parseHeader())
	{

		/* Put DIM_COMMAND bits into the command array, starting from the i bits of the received data */
		while(j<DIM_COMMAND)	/* j is the index of the command array in the packet structure */
		{
			myPacket_pointer->command[j]=data[i];
			i++;	/* i is the index of the data array */
			j++;
		}

		return parseCommand();		/* parse the command */

	}else
		return "noCommand";


}

