
/*******************************************************************************
* File Name     : data_parser.h
* Version       : 1.03
* Device(s)     : RX63N
* Tool-Chain    : Renesas RX Standard Toolchain 1.0.0
* OS            : None
* H/W Platform  : YRDKRX63N
* Description   : Library for data parser of UART wifi communciation
*******************************************************************************/
/*******************************************************************************
* History : DD.MM.YYYY     Version     Description
*         : 06.12.2019	   1.0.0       Creation
*         : 10.12.2019	   1.01		   Added macro for communication settings
*         : 13.12.2019	   1.02		   Added packet structure
*         : 15.12.2019	   1.03		   Added other macros for communication settings
*******************************************************************************/

#ifndef DATA_PARSER_H_
#define DATA_PARSER_H_


/******************************************************************************
Prototypes for exported functions
******************************************************************************/
int parseHeader();
char* parseCommand();
char* split(char*);
void clearCommand();

#endif
