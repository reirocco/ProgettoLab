
/*******************************************************************************
* File Name    : ProgettoLaboratorio.c
* Version      : 1.0
* Device(s)	   : RX63N
* Tool-Chain   : Renesas RX Standard Toolchain 2.0.8
* H/W Platform : YRDKRX63N
* Description  : Project for the Wireless Sensor of the ballbot
* note:        : Demo runs continuously.
*******************************************************************************/

/*****************************************************************************
* History : DD.MM.YYYY  Version  Description               Author
*         : 28.11.2019  1.00     First Release commented   Danilo Gervasio, Tommaso Coricelli
*         	29.11.2019	1.01	 Aggiunta prima libreria   G7
*******************************************************************************/

/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include <stdbool.h>
#include <stdio.h>
#include <machine.h>
#include "platform.h"
#include "ballbot_uart.h"

/******************************************************************************
* Function name : main
* Description   : Start the program
* Arguments     : none
* Return Value  : none
******************************************************************************/
void main(void)
{
	lcd_initialize();

	    /* Clear LCD */
	lcd_clear();

	    /* Display message on LCD */
	lcd_display(LCD_LINE1,"BallBot");
	lcd_display(LCD_LINE2,"WiFi Serial");
	lcd_display(LCD_LINE6,"Command:");



	uart_init();	/* Initialize the uart communication */

}

