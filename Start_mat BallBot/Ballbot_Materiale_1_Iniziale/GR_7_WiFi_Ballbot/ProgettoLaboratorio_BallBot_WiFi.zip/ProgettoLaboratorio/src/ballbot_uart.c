/*******************************************************************************
* File Name     : ballbot_uart.c
* Version       : 1.05
* Device(s)     : RX63N
* Tool-Chain    : Renesas RX Standard Toolchain 1.0.0
* OS            : None
* H/W Platform  : YRDKRX63N
* Description   : Library for using UART
*******************************************************************************/
/*******************************************************************************
* History : DD.MM.YYYY     Version     Description
*         : 29.11.2019     1.00        First release
*         : 01.12.2019     1.00		   Added comments
*         : 06.12.2019     1.01		   Tx and Rx works with doclight
*         : 09.12.2019 	   1.02		   Added parser library
*         : 12.12.2019	   1.03		   Added string support in tx
*         : 14.12.2019	   1.04		   Working on Rx interrupt
*         : 15.12.2019	   1.05		   Parsing the wifi received command
*******************************************************************************/
/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "ballbot_uart.h"

/******************************************************************************
Private global variables
******************************************************************************/
/* Rx and Tx queue element used for managing the reception data buffer and transmission data buffer */
queue rx_queue;
queue tx_queue;

/* Rx and Tx queue pointers */
queue* tx_queue_pointer;
queue* rx_queue_pointer;


/******************************************************************************
* Function name : interrupt_tx_init
* Description   : Initialize the TXI8 interrupt of SCI8
* Arguments     : none
* Return Value  : none
******************************************************************************/
void interrupt_tx_init()
{
	IR(SCI12,TXI12)=1;  /* Enable the interrupt in the SCI12 peripheral */
	IEN(SCI12,TXI12)=1;
}

/******************************************************************************
* Function name : interrupt_rx_init
* Description   : Initialize the RXI8 interrupt of SCI8
* Arguments     : none
* Return Value  : none
******************************************************************************/
void interrupt_rx_init()
{

	IEN(SCI12,RXI12)=1;	/* Enable the interrupt in the ICU */
}

/******************************************************************************
* Function name : rx_queue_init
* Description   : Initialize the rx queue setting the pointer to the head and the tail of the
* rx data buffer
* Arguments     : none
* Return Value  : none
******************************************************************************/
void rx_queue_init()
{
	rx_queue_pointer=&rx_queue;
	rx_queue_pointer->head=0;
	rx_queue_pointer->tail=0;
	rx_queue_pointer->counterElements=0;
	/* Empty queue conditions: head points to the same element pointed by tail and counterElements=0 */
}

/******************************************************************************
* Function name : tx_queue_init
* Description   : Initialize the tx queue setting the pointer to the head and the tail of the
* tx data buffer
* Arguments     : none
* Return Value  : none
******************************************************************************/
void tx_queue_init()
{
	tx_queue_pointer=&tx_queue;
	tx_queue_pointer->head=0;
	tx_queue_pointer->tail=0;
	tx_queue_pointer->counterElements=0;
	/* Empty queue conditions: head points to the same element pointed by tail and counterElements=0 */
}

/******************************************************************************
* Function name : uart_init
* Description   : Set up all the registers for enabling UART communication
* Arguments     : none
* Return Value  : none
******************************************************************************/
void uart_init()
{
	int timeout=0;

	 /* Enable the UART peripheral to operate */
			/* (the peripheral must be enabled before being used).*/
			/* The SCI12 channel is used because the TxD12 and RxD12 register are
			 * accessible by JN2's pins. (ref. Hardware Manual Chapt.22 page 703)*/
		    /* To enable  SCId (c=0..12)  */
			/* the register MSTP(SCId) must be activated, because*/
			/* this register is protected on writing by PRCR protection register, */
			/* before activate MSTP(SCId) it is necessary:*/
			/* a) to set off the PRCR, */
			/* b) enable desired SCIc SCIc (c=0..12) channel (in this case SCI12, c=12)*/
			/* c) to set on the PRCR. */

			#ifdef PLATFORM_BOARD_RDKRX63N
				SYSTEM.PRCR.WORD = 0xA50B; /* Protect off */
			#endif

			MSTP(SCI12)=0; /* cancel stop state of SCI12 peripheral to enable writing to it */
			/* for SCI12 PE1 is TxD12 and PE2 is RxD12 */
			#ifdef PLATFORM_BOARD_RDKRX63N
				SYSTEM.PRCR.WORD=0xA500; /* Protect off*/

			/* Protect set on  (ref. Hardware Manual Chapt.13.1.1)*/
										   /* write A5 (in hexadecimal) to the eight higher-order */
										   /* bits and 0B (in hexadecimal) to the eight lower-order */
										   /* where B in hexadecimal is equivalent to 1011 in Binary */
										   /* therefore it sets PRC3, PRC1 and PRC0 to 1 */


			#endif


			/* Set up the UART I/O port and pins */

			//MPC.PE2PFS.BIT.ISEL=1;		/*alternative code: ISEL is the interrupt (ref. Hardware Manual Chapt.22.2.16 pag 734)*/
			//MPC.PE2PFS.BIT.PSEL=0xC;	/*This value of PSEL is for RxD12 */
			MPC.PE2PFS.BYTE=0x4C;	/*P23 of JN2 is RxD12*/
			MPC.PE1PFS.BYTE=0x4C;  /*P22 of JN2 TxD12*/

			PORTE.PDR.BIT.B1=1;	  /* TxD12 is output */
			PORTE.PDR.BIT.B2=0;	  /* RxD12 is input */
			PORTE.PMR.BIT.B1=1;	  /*TxD12 is pheripheral */
			PORTE.PMR.BIT.B2=1;  /* RxD12 is a pheripheral */

			/* Set data transfer format in Serial Mode Register (SMR)  -  HW 35.2.5
			 * -Asynchronous Mode
			 * -8 bits
			 * -no parity
			 * -1 stop bit
			 * PCLK clock (n=0)
			 */
			SCI12.SMR.BYTE=0x00;
			SCI12.SCMR.BIT.SMIF=0;  /* Set to 0 for serial communications interface mode */
			SCI12.BRR=48000000 / ((64/2) * 115200) -1; /*
			/*The baud rate chosen is 115200 equals to the baud rate of the wifi module é/

			/* Clear IR bits (of the interrupt) for SCI12 registers: TXI, RXI, TEI */
			IR(SCI12,RXI12)=0;	//Clear any pending ISR
			IR(SCI12,TXI12)=0;
			IR(SCI12,TEI12)=0;

			IPR(SCI12,RXI12)=4;/* Set interrupt priority, not using the transmit end interrupt */
			IPR(SCI12,TXI12)=4;

			/* Disable all the interrupt (TXI,RXI,TEI) */
			IEN(SCI12,TXI12)=0;
			IEN(SCI12,RXI12)=0;
			IEN(SCI12,TEI12)=0;

			/* Clear SCR register: clear bits TIE, RE and TEIE in SCR to 0. Set CKE to internal */
			SCI12.SCR.BYTE=0x00;
			/* Enable RXI and TXI interrupts in SCI peripheral - (ref. Hardware Manual cp. 35.2.6 */
			SCI12.SCR.BIT.RIE=1; 	 //Reception interrupt request (RXI12) is enabled setting the bit to 1
			SCI12.SCR.BIT.TIE=1;		 	 //Transmission interrupt request (TXI12) is enabled setting the bit to 1
			SCI12.SCR.BIT.TEIE=0;   	//A TEI (Transmit End Interrupt) interrupt request is disabled, not used
			SCI12.SCR.BIT.TE=1;		//Serial transmission is enabled setting bit to 1
			SCI12.SCR.BIT.RE=1;  	//Serial reception is enabled setting bit to 1

			/* Initializing the Tx and Rx queues */
			rx_queue_init();
			tx_queue_init();



			/* Sending the setting command string to the wifi module */
			send_data(WIFI_COMMAND1,str_length(WIFI_COMMAND1));
			while (timeout++<=500000){} /*Waiting for response before of sending the next command */
			send_data(WIFI_COMMAND2,str_length(WIFI_COMMAND2));
			timeout=0;
			while (timeout++<=500000){}
			send_data(WIFI_COMMAND3,str_length(WIFI_COMMAND3));


			LED15=LED_ON;   /* Led 15 means that the uart init has been completed */


			/* Calling the initialization of interrupt for the communication */
			interrupt_rx_init();

}


/*******************************************************************************
* Function name: SCI8_TXI8_int
* Description  : Interrupt Service Routine for TXD8. It is fired when the TSR register of SCI8 is empty.
* Argument     : none
* Return value : none
*******************************************************************************/
#pragma interrupt SCI12_TXI12_int (vect = VECT_SCI12_TXI12, enable)
static void SCI12_TXI12_int()
{

	if (!queue_is_empty(tx_queue_pointer)) 	/* if the tx queue is not empty */
	{

		SCI12.TDR=tx_queue_pointer->data[tx_queue_pointer->head];	/* putting into the data buffer
		register (TDR) of the SCI8 channel the first element of the data buffer trasmission */

		tx_queue_pointer->head++;	/* Now the head of the buffer will be the next element */
		tx_queue_pointer->counterElements--;
		if (tx_queue_pointer->counterElements==0)	/* Disable the tx interrupt if all the elements have been transmitted */
			{interrupt_tx_disable();
			queue_clear(tx_queue_pointer);  /* Clear the tx queue after the transmission */
			}

	}
}

/*******************************************************************************
* Function name: SCI8_RXI8_int
* Description  : Interrupt Service Routine for RXD8. It is fired when received data are stored in RDR
* Argument     : none
* Return value : none
*******************************************************************************/
#pragma interrupt SCI12_RXI12_int (vect = VECT_SCI12_RXI12, enable)
static void SCI12_RXI12_int()
{

	int timeout=0;

		/* Frame and Parity Error handling */
	while(SCI12.SSR.BIT.ORER && timeout++<=10000)
	{
		SCI12.SSR.BIT.ORER=0;
	}

	if (SCI12.SSR.BIT.FER)
		SCI12.SSR.BIT.FER=0;
	if (SCI12.SSR.BIT.PER)
		SCI12.SSR.BIT.PER=0;

	uint8_t read_byte=SCI12.RDR;  /* Read byte from RDR register */
  /* Putting the data from RDR register into the reception buffer */
	rx_queue_pointer->data[rx_queue_pointer->tail]=	read_byte;
	rx_queue_pointer->counterElements++;		/* Incrementing the counter of received elements */
	rx_queue_pointer->tail++;	/* Incrementing the tail pointer to the next position (it will point to an empty element) */


	/* if the rx queue is full or last element of the rx queue is the '\n' we can start processing the received packet */
	if (queue_is_full(rx_queue_pointer) || rx_queue_pointer->data[rx_queue_pointer->tail-1]=='\n')	/* The wifi module sends the received command
																									to renesas with '\n' in the final position */
	{
		char command[DIM_COMMAND]=split(rx_queue_pointer);  /* splitting the received data from wifi module */
		clearCommand();	/* clear the command array for being ready for the next communication */
		/* it is not necessary to clear the header because it is overwritten every time that a packet (correct or incorrect) is received */
		interrupt_rx_disable();	/* Disabling the rx interrupt in order to clear the rx queue completely without the risk of getting other packets */
		queue_clear(rx_queue_pointer);
	}

	/* Enabling again the rx interrupt for being ready for receiving the next packet */
	interrupt_rx_init();

}





/******************************************************************************
* Function name : queue_is_full
* Description   : Check if a queue is full
* Arguments     : queue pointer to check
* Return Value  : int value --> 1 the queue is full, 0 the queue is not full
******************************************************************************/
int queue_is_full(queue* queue_pointer)
{
	if (queue_pointer->counterElements>=DIM_BUFFER)	/* If there is a number of elements equal to the buffer's dimension
													the buffer is full */
		return 1;
	else
		return 0;
}


/******************************************************************************
* Function name : queue_is_empty
* Description   : Check if a queue is empty
* Arguments     : queue pointer to check
* Return Value  : int value --> 1 the queue is empty, 0 the queue is not empty
******************************************************************************/
int queue_is_empty(queue* queue_pointer)
{
	/*The queue is empty when countElements is 0 */
	if (!queue_pointer->counterElements)
		return 1;
		else
		return 0;
}

R

/******************************************************************************
* Function name : send_data
* Description   : Send data from P21 of JN1's renesas periphal
* Arguments     : char array to transmit and its dimension
* Return Value  : none
******************************************************************************/
void send_data(char data[],  unsigned int dim_string)
{

	unsigned int i=0;	/* index for the cycle for inserting data into buffer */
	if (dim_string<(DIM_BUFFER-tx_queue_pointer->counterElements))  /* if there are sufficients empty slots */
		for (i=0;i<dim_string;i++)	/* putting each char of data array into the tx buffer */
			{
			 tx_queue_pointer->data[(tx_queue_pointer->head)+i]=data[i];  /* Putting elements from head index */
			 tx_queue_pointer->counterElements++;
			 tx_queue_pointer->tail++;
			 if (tx_queue_pointer->tail>=DIM_BUFFER)  /* Managing the tx buffer in a circular way */
				 tx_queue_pointer->tail=0;
			}
	interrupt_tx_init();
}

/******************************************************************************
* Function name : interrupt_tx_disable
* Description   : Disable TXI8 interrupt of SCI8
* Arguments     :
* Return Value  :
******************************************************************************/
void interrupt_tx_disable()
{
	IR(SCI12,TXI12)=0;
	IEN(SCI12,TXI12)=0;
}

/******************************************************************************
* Function name : interrupt_rx_disable
* Description   : Disable RXI8 interrupt of SCI8
* Arguments     :
* Return Value  :
******************************************************************************/
void interrupt_rx_disable()
{
	IEN(SCI12,RXI12)=0;
}

/******************************************************************************
* Function name : str_length
* Description   : Returns the length of the input string
* Arguments     : String
* Return Value  : int value -> Length of the string
******************************************************************************/
int str_length(char string[])
{
	unsigned int i=0;
	while(i<DIM_BUFFER)
	{
		if(string[i]==0)
			return i;
		else
			i++;
	}
	return DIM_BUFFER;
}

/******************************************************************************
* Function name : queue_clear
* Description   : Clears the buffer of the queue
* Arguments     : queue*
* Return Value  : none
******************************************************************************/
void queue_clear(queue* queue_pointer)
{
	int i;
	for(i=0; i<queue_pointer->tail; i++) /* Clear all the bits of the queue */
	{
		queue_pointer->data[i]=0;
	}
	queue_pointer->tail=0;
	queue_pointer->head=0;
	queue_pointer->counterElements=0;
}
