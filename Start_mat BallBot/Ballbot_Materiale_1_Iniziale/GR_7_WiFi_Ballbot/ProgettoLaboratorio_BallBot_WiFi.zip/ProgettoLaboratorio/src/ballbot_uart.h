/*******************************************************************************
* File Name     : ballbot_uart.h
* Version       : 1.04
* Device(s)     : RX63N
* Tool-Chain    : Renesas RX Standard Toolchain 1.0.0
* OS            : None
* H/W Platform  : YRDKRX63N
* Description   : Library for using UART
*******************************************************************************/
/*******************************************************************************
* History : DD.MM.YYYY     Version     Description
*         : 29.11.2019     1.00        First release
*         : 06.12.2019     1.01		   Tx and Rx works with doclight
*         : 10.12.2019	   1.02		   Added esp module settings
*         : 13.12.2019	   1.03		   Added new functions for esp module
*         : 15.12.2019	   1.04		   Edited functions for esp module
*******************************************************************************/

#ifndef BALLBOT_UART_H_
#define BALLBOT_UART_H_
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <machine.h>
#include "platform.h"
#include "data_parser.h"
#include "wifi_settings.h"

/******************************************************************************
Macro definitions
******************************************************************************/


/* struct used for managing the data of the communication */
typedef struct {
	unsigned char data [DIM_BUFFER];	/* chars buffer used with a circular nature */
	unsigned int head;	/* pointer to the first item of the buffer */
	unsigned int tail;	/* pointer to the last item of the buffer */
	unsigned int counterElements;
}queue;



/******************************************************************************
Prototypes for exported functions
******************************************************************************/
void uart_init();
void interrupt_tx_init();
void interrupt_tx_disable();
void interrupt_rx_init();
void interrupt_rx_disable();
void rx_queue_init();
void tx_queue_init();
void send_data(char[],unsigned int);
int queue_is_empty();
int queue_is_full();
void queue_clear(queue*);


#endif
