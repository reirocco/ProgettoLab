/******************************************************************************
* File Name: ina219.h
* Version: 1.0
* Description: Sensore ina219 con i2c
*******************************************************************************/
/*******************************************************************************
 * Author: Igor Nociaro
 *******************************************************************************/
#ifndef INA219_H_
#define INA219_H_

#include "i2c.h"

typedef struct{
	float INA_current_1;
	float INA_current_2;
	float INA_current_3;
} INA_sens;

int ina_init();

int ina_read(INA_sens*);

#endif /* INA219_H_ */
