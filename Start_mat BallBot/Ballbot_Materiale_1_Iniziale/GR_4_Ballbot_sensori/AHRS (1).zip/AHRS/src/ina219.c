/******************************************************************************
* File Name: ina219.c
* Version: 1.0
* Description: Sensore ina219 con i2c
*******************************************************************************/
/*******************************************************************************
 * Author: Igor Nociaro
 *******************************************************************************/

#include <ina219.h>

#define INA219_IIC_ADDRESS_1	0x40
#define INA219_IIC_ADDRESS_2	0x41
#define INA219_IIC_ADDRESS_3	0x42
#define CURRENT_REGISTER	0x04

int ina_init(){
	if(i2c_init())
		return 0x1;
	//inizializza x3 ina219
	return 0;
}
int ina_read(INA_sens* ina){
	uint8_t tmp;
	//ina -> INA_current_1 = i2c_read(uint8_t slave_addr, uint8_t register_number, uint8_t num_bytes,uint8_t *dest_buff);
	ina -> INA_current_1 = i2c_read(INA219_IIC_ADDRESS_1, CURRENT_REGISTER, 1, &tmp);
	ina -> INA_current_2 = i2c_read(INA219_IIC_ADDRESS_2, CURRENT_REGISTER, 1, &tmp);
	ina -> INA_current_3 = i2c_read(INA219_IIC_ADDRESS_3, CURRENT_REGISTER, 1, &tmp);
	return 0;
}
