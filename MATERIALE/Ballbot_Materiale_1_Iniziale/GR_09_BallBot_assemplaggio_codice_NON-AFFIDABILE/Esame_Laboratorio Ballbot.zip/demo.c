
/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <machine.h>
#include "platform.h"
#include "ADb10.h"
#include "cmt.h"
#include "pwm.h"
#include "sensore.h"
#include "PID.h"
#include "IMU.h"

//Variabili esterne
extern int timer_2mS;
extern int cont_calibration;
extern float sens_curr_1, sens_curr_2, sens_curr_3;
extern float volt_signal_1, volt_signal_2, volt_signal_3;

//Creazione struttura IMU
IMU_data_struct IMU;

//Creazione variabili di tipo struttura PID_Struct che verra' passata alle funzioni di gestione del PID
PIDSt_Type PID_P_curr_1;
PIDSt_Type PID_P_curr_2;
PIDSt_Type PID_P_curr_3;

//Display buffer
uint8_t  lcd_buffer[13];

//Dichiarazioni variabili per la conversione radianti-corrente sfruttata dai PID
float Ca;
float Cb1;
float Cb2;
float Cb3;
float Sb1;
float Sb2;
float Sb3;
float Sa;

//Coppia motrice di partenza motore
float C;
//Corrente di eccitazione
float Ie;
//Costante
//ke=k*Ie
float ke;
//Costante di riduzione motore
float k_rid;

//Colonne matrice T
float t1;
float t2;
float t3;

/*******************************************************************************
* Function name: DEMO
* Description  : Main program function.
* Arguments    : none
* Return value : none
*******************************************************************************/
void main(void)
{
    //Inizializzazione LCD
    lcd_initialize();
    
    //Pulizia LCD
    lcd_clear();
    
    //Messaggio sull' LCD
    lcd_display(LCD_LINE1, "Ballbot 3.0");
    lcd_display(LCD_LINE2, "PID COPPIA ");
    
    // Settaggio del tempo di clock
	CMT_init();

	//Inizializzazione IMU
	IMU_init(&IMU);

	//Inizializzazione della MTU2 per generare la PWM sul primo canale (MTIOC3A)
	PWM_Init(2); // PWM motor 2 J8-PIN 15
	PWM_Init(3); // PWM motor 3 JN2-PIN 23
	PWM_Init(4); // PWM motor 1 JN2-PIN 22

	//Inizializzazione dei parametri per il controllo PID in coppia
	init_pid(&PID_P_curr_1,SET_PARAM_PID_TORQUE);
	init_pid(&PID_P_curr_2,SET_PARAM_PID_TORQUE);
	init_pid(&PID_P_curr_3,SET_PARAM_PID_TORQUE);

	//Inizializzazione del convertitore A/D a 10-bit
	ADb10_init();

	//Inizializzazione delle porte di Direzione
	Init_Port_Dir();

	//Inizializzazione a 0 dei vettori per le tensioni lette dai sensori di corrente
	vettore_vout_init();

    //This is the main loop.
	while (1)
    {
		//Acquisizione dati nella struttura IMU
		IMU_result(&IMU);

		//Calcolo variabili per la conversione radianti-corrente sfruttata dai PID
        Ca = cos(IMU.RollRad);
		Cb1 = cos(IMU.PitchRad);
		Cb2 = cos(IMU.PitchRad + 2*M_PI/3);
		Cb3 = cos(IMU.PitchRad - 2*M_PI/3);
		Sb1 = sin(IMU.PitchRad);
		Sb2 = sin(IMU.PitchRad + 2*M_PI/3);
		Sb3 = sin(IMU.PitchRad - 2*M_PI/3);
		Sa = sin(IMU.RollRad);

		//Assegnazione valori
		k_rid = 1;
		Ie = 5.5;
		C = 49.03;
		//Calcolo costante ke
		ke = (C/Ie)*k_rid;

		//Lettura dei valori di tensione legati alla corrente inviata ai motori e relativa conversione in corrente
		sens_read();

		//Calcolo colonne matrice T
		t1 = ke*sens_curr_1;
		t2 = ke*sens_curr_2;
		t3 = ke*sens_curr_3;

		//Assegnazione valori di corrente ai PID con l'uso della matrice T
		PID_P_curr_1.uc = Ca*(t1*Cb1+Cb2+t3*Cb3);
		PID_P_curr_2.uc = Ca*(t1*Sb1+Sb2+t3*Sb3);
		PID_P_curr_3.uc = -Sa*(t1+t2+t3);

    	//Ciclo che scandisce l'acquisizione dei dati dai sensori di corrente
    	if(timer_2mS)
    		{
    			timer_2mS = 0;
    			if(cont_calibration < calibration_length)
    			{
    					//Stampa a video dell'avviso di calibrazione dei sensori di corrente
    					sprintf((char *)lcd_buffer, "Calibrating");
    					lcd_display(LCD_LINE4, lcd_buffer);
    					sprintf((char *)lcd_buffer, "Sensors...");
    					lcd_display(LCD_LINE5, lcd_buffer);

    					//Funzione di calibrazione dei sensori di corrente
    				    sens_calibration_init();
    			}
    			else if (cont_calibration == calibration_length)
    				//Calcolo del bias calcolato su 1000 elementi da sottrare al valore letto dai sensori
    				sens_calibration_bias();
    			else
    			{
    				//Lettura dei valori di tensione legati alla corrente inviata ai motori e relativa conversione in corrente
    				sens_read();

    				sprintf((char *)lcd_buffer, "C1=%f",sens_curr_1);
    				lcd_display(LCD_LINE4, lcd_buffer);

    				//Assegnazione dei valori letti dal sensore di corrente alla struttura attuale del PID
    			  	//per il controllo in corrente
    				PID_P_curr_1.y=sens_curr_1;
    				PID_P_curr_2.y=sens_curr_2;
    				PID_P_curr_3.y=sens_curr_3;

    				//Calcolo del segnale di controllo da inviare ai motori
    				//Inviamo il segnale di riferimento curr_ref al PID in corrente che provvedera' a generare
    				//il segnale di controllo che invieremo ai motori.
    				calcPID(&PID_P_curr_1);
    				calcPID(&PID_P_curr_2);
    				calcPID(&PID_P_curr_3);
    				volt_signal_1 = PID_P_curr_1.output;
    				volt_signal_2 = PID_P_curr_2.output;
    				volt_signal_3 = PID_P_curr_3.output;

    				//Controllo del verso di rotazione
    				motor_direction();

    				//Calcolo del Duty-Cycle da inviare ai motori
    				DutyCycle_to_Motor();
    			}
    		}//Fine ciclo acquisizione dati e controllo (2ms)
   }

} //Fine main()
